console.log("Hello world");
var socket = io();
//write your socket events here from the client to the server
