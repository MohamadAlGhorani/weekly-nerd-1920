const videoElement = document.getElementById("video");

Promise.all([
  faceapi.nets.tinyFaceDetector.loadFromUri("/models"),
  faceapi.nets.faceLandmark68Net.loadFromUri("/models"),
  faceapi.nets.faceRecognitionNet.loadFromUri("/models"),
  faceapi.nets.faceExpressionNet.loadFromUri("/models"),
  faceapi.nets.ageGenderNet.loadFromUri("/models"),
]).then(startWebcam);

function startWebcam() {
  // request cam
  navigator.mediaDevices
    .getUserMedia({
      video: true,
    })
    .then((stream) => {
      // save stream to variable at top level so
      // it can be stopped lateron
      webcamStream = stream;
      // show stream from the webcam on te
      // video element
      videoElement.srcObject = stream;
      // returns a Promise to indicate if
      // the video is playing
      return videoElement.play();
    })
    .catch((e) => console.log("error: " + e));
}

var videoContainer = document.querySelector(".video-container");

videoElement.addEventListener("play", () => {
  const canvas = document.createElement("canvas");
  videoContainer.append(canvas);
  const displaySize = {
    width: videoElement.width,
    height: videoElement.height,
  };
  faceapi.matchDimensions(canvas, displaySize);
  setInterval(async () => {
    const detections = await faceapi
      .detectAllFaces(videoElement, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceExpressions()
      .withAgeAndGender();
    const resizedDetections = faceapi.resizeResults(detections, displaySize);
    canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
    faceapi.draw.drawDetections(canvas, resizedDetections);
    faceapi.draw.drawFaceLandmarks(canvas, resizedDetections);
    faceapi.draw.drawFaceExpressions(canvas, resizedDetections);
    resizedDetections.forEach((result) => {
      const { age, gender, genderProbability } = result;
      new faceapi.draw.DrawTextField(
        [
          `${faceapi.round(age, 0)} years`,
          `${gender} (${faceapi.round(genderProbability)})`,
        ],
        result.detection.box.bottomRight
      ).draw(canvas);
    });
    console.log(detections);
    detections.forEach((person) => {
      if (person.age && person.age < 16) {
        console.log("age is under 16 years");
      } else {
        console.log("older than 16 years");
      }
    });
  }, 100);
});
